# Servidor Multiplayer — Presidente por um Dia

## O que estava acontecendo

O jogo (`index.html`) já tinha o multiplayer todo pronto — criar sala, entrar
com código, votar em crises — mas ele foi construído originalmente pra rodar
como *artifact* do Claude, usando uma API chamada `window.storage` que só
existe dentro do Claude.ai. Fora daquele ambiente, todas as chamadas de
armazenamento falhavam silenciosamente, e por isso criar/entrar em sala nunca
funcionava — ficava só mostrando "conexão instável".

## O que este pacote resolve

`server.js` é um servidor Node.js simples que expõe uma **API de chave/valor**
compatível com o que o jogo já esperava (`storGet`, `storSet`, `storList`,
`storDelete` no código do jogo). Não usa WebSocket — o jogo funciona por
**polling**: cada jogador consulta o servidor a cada poucos segundos pra ver
se algo mudou na sala (novos jogadores, novos votos, próxima crise, etc).

Rotas da API:
- `GET /api/kv/:key` — lê um valor
- `PUT /api/kv/:key` — grava um valor
- `DELETE /api/kv/:key` — apaga um valor
- `GET /api/kv?prefix=xxx` — lista chaves com um prefixo (usado pra listar
  jogadores de uma sala, por exemplo)

O `index.html` incluído já está ajustado pra chamar essas rotas — não precisa
mexer em mais nada.

Também troquei o "salvar progresso" e o "recorde pessoal" (que são dados só
seus, não precisam de servidor) pra usar `localStorage` do navegador, em vez
de `window.storage`.

## Testado e funcionando

Testei localmente todo o fluxo: criar sala, segundo jogador entrar com
código, iniciar o jogo, e votar numa crise — os dois jogadores sincronizam
corretamente via polling no servidor.

## Como colocar no ar (Render — grátis)

1. Crie uma conta em [github.com](https://github.com) se ainda não tiver
2. Crie um repositório novo (pode ser público)
3. Suba os 3 arquivos deste pacote pra raiz do repositório:
   `server.js`, `package.json`, `index.html`
4. Crie uma conta em [render.com](https://render.com) (dá pra logar com GitHub)
5. No painel: **New +** → **Web Service** → conecte o repositório
6. Configure:
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Instance Type:** Free
7. Clique em criar. Em 1–3 minutos você recebe uma URL tipo
   `https://seu-jogo.onrender.com`

Abra essa URL — o jogo carrega e o multiplayer já funciona, sem precisar
mudar nada no código, porque o `index.html` já está servido pelo mesmo
servidor que atende a API.

**Detalhe do plano grátis:** o serviço "dorme" depois de 15 minutos sem uso e
demora uns 30-60 segundos pra acordar na próxima visita. Depois disso fica
rápido normalmente.

## Testando localmente antes de publicar

```bash
cd mp-server
npm install
npm start
```

Servidor sobe em `http://localhost:3000`. Se `index.html` estiver na mesma
pasta, abra essa URL no navegador — já dá pra testar criar sala e entrar de
outra aba/dispositivo na mesma rede.
